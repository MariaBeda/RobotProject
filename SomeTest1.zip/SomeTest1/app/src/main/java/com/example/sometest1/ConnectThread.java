package com.example.sometest1;

import android.bluetooth.BluetoothAdapter;

public class ConnectThread extends Thread {

}
